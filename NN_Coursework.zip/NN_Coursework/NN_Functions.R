#Neural Network visualization Code
NN_Visualize_Model<- function(data, hidden, targetfield){
  #Formula to pass to the neural network
  Input_Fields <- colnames(data)
  predictorVars <- Input_Fields[1:ncol(data)-1]
  predictorVars <- paste(predictorVars, collapse = "+")
  form=as.formula(paste(targetfield,"~", predictorVars))
  
  #Neural Network Visualization
  neuralModel = neuralnet(formula = form, hidden = hidden, linear.output = F, 
                          lifesign = 'full', rep = 1, data = data)
  plot(neuralModel, col.hidden = "darkgreen", col.hidden.synapse = "darkgreen",
       show.weights = F, information = F, fill = "lightblue")
}

#Normalization of the data
NN_Normalize <- function(data){
  maxvalue <- apply(data,2,max)
  minvalue <- apply(data,2,min)
  data <- as.data.frame(scale(data, center = minvalue, scale = maxvalue-minvalue))
  return(data)
}

#MLP Neural Network for Regression task
NN_Regression_TrainandEvaluate <- function(train_data, test_data, hidden, target_field){
  
  train_df <- train_data[,1:ncol(train_data)-1]
  train_target <- as.matrix(train_data[,target_field])
  test_df <- test_data[,1:ncol(test_data)-1]
  test_target <- as.matrix(test_data[,target_field])
  
  #Create Model
  model <- keras_model_sequential()
  model %>% keras::layer_dense(units=ncol(train_df), activation = 'relu', input_shape = ncol(train_df)) %>%
    keras::layer_dropout(rate=0.1) %>%
    keras::layer_dense(units=hidden, activation = 'relu') %>%
    keras::layer_dropout(rate=0.1) %>%
    keras::layer_dense(unit=1, activation = "linear")
  
  #Inspection of model
  summary(model)
  
  #Compile and Fit Code
  model %>% keras::compile(loss='mse', optimizer = 'rmsprop', metrics = list('mae'))
  model_1 <- model %>% keras::fit(x=as.matrix(train_df), y=train_target, batch_size = BATCH_SIZE,
                                  epochs = EPOCH,validation_split=0.2, verbose=0)
  print(plot(model_1))
  print(plot(model_1$metrics$mae, main="Train: Mean Absolute Error", xlab = "epoch", ylab="MAE", col="blue", type="l"))
  measure <- model %>% evaluate(as.matrix(test_df), test_target)
  print(measure)
  
  #Predict the results
  predicted <- model %>% predict(as.matrix(test_df))
  result <- caret::postResample(predicted, test_target)
  print(result)
  print(plot(test_target, predicted, xlab = "Actual Data", ylab="Predicted Data"))
}


NN_Regression_TrainandEvaluate_KFold <- function(train_data, test_data, hidden, target_field,NoFolds){

  test_df <- test_data[,1:ncol(test_data)-1]
  test_target <- as.matrix(test_data[,target_field])
  #Split the training data into K Folds
  folds <- createFolds(y=train_data[,ncol(train_data)], k = NoFolds, list=F)
  train_data$folds <- folds
  modellist <- list()
  for (f in unique(train_data$folds)){
    print(paste("\n Fold: ", f))
    ind <- which(train_data$folds == f)
    train_df <- train_data[-ind,1:(ncol(train_data)-2)]
    train_target <- as.matrix(train_data[-ind,target_field])
    valid_df <- train_data[ind,1:(ncol(train_data)-2)]
    valid_target <- as.matrix(train_data[ind,target_field])
    
    #Create Model
    model <- keras_model_sequential()
    model %>% keras::layer_dense(units=ncol(train_data)-2, activation = 'relu', input_shape = ncol(train_data)-2) %>%
      keras::layer_dropout(rate=0.1) %>%
      keras::layer_dense(units=hidden, activation = 'relu') %>%
      keras::layer_dropout(rate=0.1) %>%
      keras::layer_dense(unit=1, activation = "linear")
    
    #Inspection of model
    summary(model)
    
    #Compile and Fit Code
    model %>% keras::compile(loss='mse', optimizer = 'rmsprop', metrics = list('mae'))
    
    model_1 <- model %>% keras::fit(x=as.matrix(train_df), y=train_target, batch_size = BATCH_SIZE,
                                    epochs = EPOCH,validation_data = list(as.matrix(valid_df),valid_target),
                                    verbose=0)
    
    #Visualizing the model
    #plot(model_1)
    
    # Plot the accuracy of the training data 
    print(plot(model_1$metrics$mae, main="Train: Mean Absolute Error", xlab = "epoch", ylab="MAE", col="blue", type="l"))
    print(plot(model_1$metrics$loss, main="Train: Loss", xlab = "epoch", ylab="loss", col="blue", type="l"))
    print(plot(model_1$metrics$val_mae, main="Validation: Mean Absolute Error", xlab = "epoch", ylab="MAE", col="blue", type="l"))
    print(plot(model_1$metrics$val_loss, main="Validation: Loss", xlab = "epoch", ylab="loss", col="blue", type="l"))
    
    #Evaluate Model
    measure <- model %>% evaluate(as.matrix(test_df), test_target)
    modellist[[f]] <- measure
  }
  #Predict the values
  predicted <- model %>% predict(as.matrix(test_df))
  result <- caret::postResample(predicted, test_target)
  print(result)
  print(plot(test_target, predicted, xlab = "Actual Data", ylab="Predicted Data"))
  print(modellist)
}

NN_Classifier_TrainandEvaluate <- function(train_data, test_data, hidden, target_field){

  train_df <- train_data[,1:ncol(train_data)-1]
  test_df <- test_data[,1:ncol(test_data)-1]
  
  train_target <- as.matrix(train_data[, target_field])
  test_target <- as.matrix(test_data[, target_field])
  
  #One hot Encoding
  trainlabels <- keras::to_categorical(train_target)
  testlabels <- keras::to_categorical(test_target)
  
  #Create Model
  model <- keras_model_sequential()
  model %>% keras::layer_dense(units=ncol(train_df), activation = 'relu', input_shape = ncol(train_df)) %>%
    keras::layer_dropout(rate=0.1) %>%
    keras::layer_dense(units=hidden, activation = 'relu') %>%
    keras::layer_dropout(rate=0.1) %>%
    keras::layer_dense(unit=4, activation = "softmax")
  
  #Compile and Fit Code
  model %>% keras::compile(loss="categorical_crossentropy", optimizer = 'adam', metrics = "accuracy")
  
  model_1 <- model %>% keras::fit(x=as.matrix(train_df), y=trainlabels, batch_size = 128,epochs = 100,
                                  validation_split = 0.2, verbose=0)
  #Visualizing the model
  print(plot(model_1))
  
  #Evaluate the model
  model %>% evaluate(as.matrix(test_df), testlabels)
  
  #Prediction & Confusion Matrix
  predictedClass <- model %>% predict_classes(as.matrix(test_df))
  resulttab <- table(Actual = test_target,Predicted = predictedClass)
  results <- confusionMatrix(resulttab)
  print(results)
  print(paste("Accuracy = ",results$overall['Accuracy']))
  
  #Plot Results
  print(ggplot(as.data.frame(results$table), aes(Predicted,Actual, fill=Freq)) +
          geom_tile() + geom_text(aes(label=Freq))+
          scale_fill_gradient(low="white", high="#009194") +
          labs(x = "Actual",y = "Prediction") +
          scale_x_discrete(labels=c("Band A","Band B","Band C","Band D")) +
          scale_y_discrete(labels=c("Band A","Band B","Band C","Band D")))
}

NN_Classifier_TrainandEvaluate_KFold <- function(train_data, test_data, hidden, target_field,NoFolds){

  test_df <- test_data[,1:ncol(test_data)-1]
  test_target <- as.matrix(test_data[, target_field])
  
  #Split the training data into K Folds
  folds <- createFolds(y=train_data[,ncol(train_data)], k = NoFolds, list=F)
  train_data$folds <- folds
  modellist <- list()

  for (f in unique(train_data$folds)){
    print(paste("\n Fold: ", f))
    ind <- which(train_data$folds == f)
    train_df <- train_data[-ind,1:(ncol(train_data)-2)]
    train_target <- as.matrix(train_data[-ind, target_field])
    valid_df <- train_data[ind,1:(ncol(train_data)-2)]
    valid_target <- as.matrix(train_data[ind,target_field])
  
    #One hot Encoding
    trainlabels <- keras::to_categorical(train_target)
    testlabels <- keras::to_categorical(test_target)
    validlabels <- keras::to_categorical(valid_target)
  
    #Create Model
    model <- keras_model_sequential()
    model %>% keras::layer_dense(units=ncol(train_df), activation = 'relu', input_shape = ncol(train_df)) %>%
              keras::layer_dropout(rate=0.1) %>%
              keras::layer_dense(units=hidden, activation = 'relu') %>%
              keras::layer_dropout(rate=0.1) %>%
              keras::layer_dense(unit=4, activation = "softmax")
  
    #Compile and Fit Code
    model %>% keras::compile(loss="categorical_crossentropy", optimizer = 'adam', metrics = "accuracy")
  
    model_1 <- model %>% keras::fit(x=as.matrix(train_df), y=trainlabels, batch_size = 128,epochs = 100,
                                    validation_data = list(as.matrix(valid_df),validlabels), verbose=0)

    #Evaluate the model
    measure <- model %>% evaluate(as.matrix(test_df), testlabels)
  
    #Calculate Accuracy
    modellist[[f]] <- measure
  }
  print(plot(model_1))
  #Prediction & Confusion Matrix
  predictedClass <- model %>% predict_classes(as.matrix(test_df))
  resulttab <- table(Actual = test_target,Predicted = predictedClass)
  results <- confusionMatrix(resulttab)
  print(results)
  print(paste("Accuracy = ",results$overall['Accuracy']))
  #Plot Results
  print(ggplot(as.data.frame(results$table), aes(Predicted,Actual, fill=Freq)) +
          geom_tile() + geom_text(aes(label=Freq))+
          scale_fill_gradient(low="white", high="#009194") +
          labs(x = "Actual",y = "Prediction") +
          scale_x_discrete(labels=c("Band A","Band B","Band C","Band D")) +
          scale_y_discrete(labels=c("Band A","Band B","Band C","Band D")))
  
  print(modellist)
  return(modellist)
}
