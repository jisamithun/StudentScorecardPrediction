library(caret)
library(dplyr)
library(keras)
library(tensorflow)
library(magrittr)
library(neuralnet)

#Parameters for NN-Model defined here
DATASET_FILENAME  <- "ScoreCard_cleaner_Dataset.csv"
OUTPUT_FIELD <- "md_earn_wne_p10"
NN_HIDDEN = 16
EPOCH = 100
BATCH_SIZE = 128
NoFolds = 10

setwd("D:\\DataScience\\SEM1\\PracticalBusinessAnalytics(COMM053)\\Coursework\\NNProject")
source("NN_Functions.R")
dataset <- read.csv(DATASET_FILENAME,encoding="UTF-8",stringsAsFactors = T)
dataset <- dataset[,c(3:6,17:34)]

#Data should be in numeric
dataset %<>% mutate_if(is.factor,as.numeric)

# Visualization of Neural network
#NN_Visualize_Model(dataset, NN_HIDDEN, OUTPUT_FIELD)

#Step:1 Normalize the data

dataset <- NN_Normalize(dataset)

#Step2: Create Training and Test Data
set.seed(123)
# Determine sample size
splitdata <- sample(2, nrow(dataset), replace=TRUE, prob=c(0.7, 0.3))
# Split the Input Dataset
data.training <- dataset[splitdata==1, 1:ncol(dataset)]
data.test <- dataset[splitdata==2, 1:ncol(dataset)]
#data.testtarget <- dataset[splitdata==2, ncol(dataset)]

#Train the data using MLP Neural Network-Regression mode
#NN_Regression_TrainandEvaluate(data.training,data.test,NN_HIDDEN,OUTPUT_FIELD)

#Train the data using MLP Neural Network-Regression mode with K-Folds
NN_Regression_TrainandEvaluate_KFold(data.training,data.test,NN_HIDDEN,OUTPUT_FIELD,NoFolds)