library(dplyr)
library(magrittr)
library(keras)
library(tensorflow)
library(tfruns)
library(caret)
library(ggplot2)

#Parameters for NN-Model defined here
DATASET_FILENAME  <- "ScoreCard_cleaner_Dataset.csv"
OUTPUT_FIELD <- "SalaryBand"
NN_HIDDEN = 16
EPOCH = 50
BATCH_SIZE = 128
NoFolds = 10

setwd("D:\\DataScience\\SEM1\\PracticalBusinessAnalytics(COMM053)\\Coursework\\NNProject")
source("NN_Functions.R")
dataset <- read.csv(DATASET_FILENAME,encoding="UTF-8",stringsAsFactors = T)
dataset <- dataset[,c(3:6,17:34)]
str(dataset)

Salary_Band <- cut(dataset$md_earn_wne_p10, breaks = c(min(dataset$md_earn_wne_p10)-1, 
                                                       quantile(dataset$md_earn_wne_p10, probs=0.25),
                                                       median(dataset$md_earn_wne_p10), 
                                                       quantile(dataset$md_earn_wne_p10, probs=0.75),
                                                       max(dataset$md_earn_wne_p10)), labels = c("BandA", "BandB",
                                                                                                 "BandC", "BandD"))

dataset <- dataset %>% mutate(SalaryBand = Salary_Band)

#Convert the Salary Class into numeric labels
dataset$SalaryBand <- factor(dataset$SalaryBand, levels = c("Band A", "Band B",
                                                            "Band C", "Band D"), labels = c(1,2,3,4))
dataset <- dataset[,c(1:21,23)]

#Convert Factors to Numeric
dataset %<>% mutate_if(is.factor,as.numeric)

# Visualization of Neural network
NN_Visualize_Model(dataset, NN_HIDDEN, OUTPUT_FIELD)

#Step:1 Normalize the data
dataset[,1:(ncol(dataset)-1)] <- NN_Normalize(dataset[,1:(ncol(dataset)-1)])
dataset[,OUTPUT_FIELD] <- dataset[,OUTPUT_FIELD]-1

#Step2: Create Training and Test Data
set.seed(123)
# Determine sample size
splitdata <- sample(2, nrow(dataset), replace=TRUE, prob=c(0.67, 0.33))
# Split the Input Dataset
data.training <- dataset[splitdata==1, 1:ncol(dataset)]
data.test <- dataset[splitdata==2, 1:ncol(dataset)]

#Train the data with MLP-Neural Network for Classification mode
#NN_Classifier_TrainandEvaluate(data.training,data.test,NN_HIDDEN,OUTPUT_FIELD)

#Train the data with MLP-Neural Network for Classification mode with K Folds
modelresult <- NN_Classifier_TrainandEvaluate_KFold(data.training,data.test,NN_HIDDEN,OUTPUT_FIELD, NoFolds)

